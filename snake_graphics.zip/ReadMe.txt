Create a 'graphics' folder in pygame location.
Unzip image files in created 'graphics' folder.